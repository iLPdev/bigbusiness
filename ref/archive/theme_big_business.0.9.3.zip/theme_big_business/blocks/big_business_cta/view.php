<!--
Big Business CTA for Concrete5 by iLP - http://www.concrete5.org/profile/-/view/82852/
-->
<?php    
	defined('C5_EXECUTE') or die(_("Access Denied."));
	$form = Loader::helper('form');
?>

<h3><?php  echo $heading?></h3>

<ul class="section-list">

	<li class="first">
		<img class="pic alignleft" src="<?php echo $this->getThemePath(); ?>/img/pic02.jpg" width="70" height="70" alt="" />
		<span class="ctaTitle"><?php  echo $ctaTitle1?></span><br />
		<span class="ctaDesc"><?php  echo $ctaDesc1?></span>
	</li>

	<li>
		<img class="pic alignleft" src="<?php echo $this->getThemePath(); ?>/img/pic02.jpg" width="70" height="70" alt="" />
		<span class="ctaTitle"><?php  echo $ctaTitle2?></span><br />
		<span class="ctaDesc"><?php  echo $ctaDesc2?></span>
	</li>

	<li class="last">
		<img class="pic alignleft" src="<?php echo $this->getThemePath(); ?>/img/pic02.jpg" width="70" height="70" alt="" />
		<span class="ctaTitle"><?php  echo $ctaTitle3?></span><br />
		<span class="ctaDesc"><?php  echo $ctaDesc3?></span>
	</li>

</ul>