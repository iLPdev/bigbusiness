<!--
Big Business CTA for Concrete5 by iLP - http://www.concrete5.org/profile/-/view/82852/
-->
<?php 
	defined('C5_EXECUTE') or die(_("Access Denied."));
	
	class BigBusinessCtaBlockController extends BlockController {
		
		var $pobj;
		
		protected $btDescription = "Adds Call to Action block to the Big Business theme.";
		protected $btName = "Big Business CTA";
		protected $btTable = 'btBigBusinessCta';
		protected $btInterfaceWidth = "600";
		protected $btInterfaceHeight = "300";
		
	}
	
?>