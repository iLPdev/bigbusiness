<?php
defined('C5_EXECUTE') or die(_("Access Denied."));
?>

<div id="footer">
	&copy; <?php echo date('Y')?> <a href="<?php echo DIR_REL?>/"><?php echo SITE?></a>.
	<?php echo t('All rights reserved.')?>
		Design by <a href="http://www.freecsstemplates.org/">Free CSS Templates</a>. Big Business Theme by <a href="http://www.concrete5.org/profile/-/view/82852/">iLP</a>.			
	<?php
	$u = new User();
	if ($u->isRegistered()) { ?>
		<?php
		if (Config::get("ENABLE_USER_PROFILES")) {
			$userName = '<a href="' . $this->url('/profile') . '">' . $u->getUserName() . '</a>';
		} else {
			$userName = $u->getUserName();
		}
		?>
		<?php echo t('| Logged in as <b>%s</b>.', $userName)?> <a href="<?php echo $this->url('/login', 'logout')?>"><?php echo t('Sign Out')?></a>
	<?php  } else { ?>
		<a href="<?php echo $this->url('/login')?>"><?php echo t('| Login')?></a>
	<?php  } ?>
	<br />
	<a href="http://www.concrete5.org/r/-/82852" title="<?php echo t('concrete5 - open source content management system for PHP and MySQL')?>"><img class="pic" src="<?php echo $this->getThemePath(); ?>/img/concrete5logo_horiz_200px.png" width="200" height="41" alt="concrete5" /></a>
</div>

<?php Loader::element('footer_required'); ?>
</body>
</html>