<!--
Big Business CTA for Concrete5 by iLP - http://www.concrete5.org/profile/-/view/82852/
-->
<?php    
	defined('C5_EXECUTE') or die(_("Access Denied."));
	$form = Loader::helper('form');
?>
	
<div class="ccm-ui">

	<div style="margin: 0 0 15px 0";>
		Use valid HTML for styling and links.
	</div>

	<div style="margin: 0 0 15px 0; font-weight: strong;">
		<?php  echo $form->label('heading', 'CTA Box Heading:');?>
		<?php  echo $form->text('heading', $heading, array('style' => 'width: 470px'));?>
	</div>

	<div>
		<?php  echo $form->label('ctaTitle1', 'CTA Title #1:');?>
		<?php  echo $form->text('ctaTitle1', $ctaTitle1, array('style' => 'width: 470px'));?>
	</div>

	<div style="margin: 0 0 15px 0";>
		<?php  echo $form->label('ctaDesc1', 'CTA Description #1:');?>
		<?php  echo $form->text('ctaDesc1', $ctaDesc1, array('style' => 'width: 470px'));?>
	</div>

	<div>
		<?php  echo $form->label('ctaTitle2', 'CTA Title #2:');?>
		<?php  echo $form->text('ctaTitle2', $ctaTitle2, array('style' => 'width: 470px'));?>
	</div>

	<div style="margin: 0 0 15px 0";>
		<?php  echo $form->label('ctaDesc2', 'CTA Description #2:');?>
		<?php  echo $form->text('ctaDesc2', $ctaDesc2, array('style' => 'width: 470px'));?>
	</div>

	<div>
		<?php  echo $form->label('ctaTitle3', 'CTA Title #3:');?>
		<?php  echo $form->text('ctaTitle3', $ctaTitle3, array('style' => 'width: 470px'));?>
	</div>

	<div>
		<?php  echo $form->label('ctaDesc3', 'CTA Description #3:');?>
		<?php  echo $form->text('ctaDesc3', $ctaDesc3, array('style' => 'width: 470px'));?>
	</div>
	
</div>